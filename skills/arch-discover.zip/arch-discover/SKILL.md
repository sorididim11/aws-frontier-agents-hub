---
name: arch-discover
description: >
  아키텍처 분석 요청 시 적용. 사용자가 #arch-q1 또는 #arch-q2 트리거를 보내면
  표준 JSON 포맷으로 앱 식별(Q1) 또는 서비스 상세(Q2) 데이터를 구조화하여 응답한다.
  환경의 애플리케이션 목록, 서비스 연결 관계, 워크플로우를 그래프 렌더링에 직접
  사용 가능한 JSON으로 제공한다.
agent_types:
  - Generic
---

# arch-discover — 아키텍처 분석 스킬

앱에서 `#arch-q1` 또는 `#arch-q2` 트리거를 보내면, 이 스킬의 포맷과 규칙에 따라 응답합니다.

---

## 트리거

- `#arch-q1` — 환경의 앱 식별 (Q1)
- `#arch-q2 {app_id} {app_name}` — 특정 앱의 서비스 상세 (Q2)

---

## Q1: 앱 식별

### 역할
이 환경에서 관리되는 애플리케이션 목록, 앱 간 관계, 비즈니스 워크플로우를 식별합니다.

### 응답 순서
1. 자연어 설명 (앱 목록, 역할, 관계)
2. 아래 JSON 포맷으로 구조화된 데이터 (`\`\`\`json` 코드블록 안에)

### Q1 출력 포맷
```json
{
  "system_name": "환경 이름",
  "description": "전체 환경 설명 (한국어)",
  "apps": [
    {
      "id": 1,
      "name": "앱제품명",
      "description": "앱 목적 (한국어)",
      "classification_criteria": "이 앱에 속하는 서비스와 그 이유 (한국어)"
    }
  ],
  "app_edges": [
    {
      "source": "앱이름1",
      "target": "앱이름2",
      "description": "관계 설명 (한국어)"
    }
  ],
  "app_workflows": [
    {
      "name": "워크플로우 제목 (한국어)",
      "hops": ["앱이름1", "앱이름2", "앱이름3"]
    }
  ]
}
```

### Q1 규칙
- **필수 필드**: system_name, description, apps, app_edges
- **앱 필수 필드**: id, name, description
- **앱 이름** = 제품/프로젝트 고유 이름 (예: DockerCoins, AlarmPipeline)
  - 금지: 기능 카테고리(UserManagement), 기술 영역(Observability), 방법론(ChaosEngineering, Monitoring, Security, Networking, Storage, Compute)
- 앱 전용 데이터 저장소, 큐, 알람은 해당 앱 그룹에 포함
- 운영 파이프라인(알람→알림→조사)은 해당 앱에 포함하거나, 여러 앱을 서빙하면 별도 앱으로 분리
- app_edges: source = 시작하는 앱, target = 받는 앱. **양방향 edge 금지**
- app_workflows: hops = 비즈니스 흐름 순서대로 앱 이름 배열
- 각 앱에 숫자 id 부여 (1부터 시작, Q2 참조용)
- 모든 텍스트는 **한국어**

---

## Q2: 앱별 서비스 상세

### 역할
특정 앱의 모든 서비스/리소스, 연결 관계, 워크플로우를 graph 포맷으로 수집합니다.

### 핵심 원칙
**연결 체인을 끝까지 추적하세요.** 이 앱의 서비스에서 시작하여, 연결된 모든 리소스를 앱 경계와 관계없이 끝까지 따라가세요.

### 응답 순서
1. 자연어 설명 (서비스 목록, 역할, 연결 방식)
2. 아래 JSON 포맷으로 구조화된 데이터 (`\`\`\`json` 코드블록 안에)

### Q2 출력 포맷
```json
{
  "app_name": "{app_name}",
  "nodes": [
    {
      "name": "고유-kebab-case-id",
      "namespace": "",
      "kind": "Amazon EKS Deployment",
      "service_type": "app",
      "group": "실제 소속 앱 이름",
      "labels": { "role": "역할 설명 (한국어)" },
      "ports": [8080]
    }
  ],
  "edges": [
    {
      "source": "호출자-서비스명",
      "target": "대상-서비스명",
      "protocol": "http",
      "port": 80,
      "paths": ["/path"],
      "description": "목적 (한국어)"
    }
  ],
  "workflows": [
    {
      "name": "워크플로우 제목 (한국어)",
      "hops": [
        { "from": "서비스-a", "to": "서비스-b" },
        { "from": "서비스-b", "to": "서비스-c" }
      ]
    }
  ]
}
```

### Q2 필드 규칙

#### Node 필드
| 필드 | 규칙 |
|------|------|
| name | 고유 kebab-case 식별자. 모든 앱에 걸쳐 고유 |
| namespace | K8s 워크로드: `""`, AWS 관리형: `"managed"`, 외부/cross-account: `"external"` |
| kind | `"<AWS 서비스> <리소스 타입>"` (예: "Amazon EKS Deployment", "Amazon DynamoDB Table", "AWS Lambda Function", "Amazon CloudWatch Alarm", "Amazon SNS Topic") |
| service_type | 비즈니스 역할만: `app`, `cache`, `db`, `gateway`, `queue`, `worker`, `observe`, `ops`, `platform`. **"managed" 사용 금지** — kind에서 유추 가능 |
| group | 실제 소속 앱 이름. 다른 앱에 속하면 그 앱 이름, 여러 앱 공유 시 주 소유 앱 |
| labels.role | 서비스 목적 (한국어) |
| ports | 리스닝 포트 배열. 해당 없으면 `[]` |

- K8s Service 리소스(ClusterIP, LoadBalancer, NodePort)는 노드로 만들지 않는다. Deployment과 실제 리소스만.

#### Edge 규칙
- source = 데이터를 시작/전송하는 서비스, target = 받는 서비스
- **양방향 edge 금지**: A→B가 있으면 B→A 안 됨
- "모니터링한다", "참조한다", "소유한다" = edge가 아님. **실제 데이터 전송만** edge
- protocol: `http`, `https`, `tcp`, `grpc`
- **앱 경계를 넘는 edge도 반드시 포함**

#### Workflow 규칙
- hops[].from/to = nodes[].name과 정확히 일치
- 각 hop = 실제 네트워크 호출 또는 이벤트 1건
- 배열 순서 = 실행 시간 순서
- **앱 경계를 넘는 워크플로우도 end-to-end로 표현**

### Q2 검증 체크리스트 (응답 전 확인)
- [ ] 모든 노드에 최소 하나의 edge가 있는가 (고아 노드 없음)
- [ ] 양방향 edge가 없는가
- [ ] 모든 edge의 source/target이 nodes에 존재하는가
- [ ] 모든 워크플로우 hop의 from/to가 nodes에 존재하는가
- [ ] 연결 체인의 끝까지 추적했는가
- [ ] 모든 노드에 kind와 group이 있는가

### Q2 필수 필드
- **필수**: app_name, nodes, edges
- **노드 필수**: name, namespace, kind, service_type, group, labels
- **Edge 필수**: source, target, description

---

## 공통 규칙
- 모든 description, role, name 필드는 **한국어** 작성
- JSON은 렌더링에 직접 사용되므로 **형식을 정확히** 따를 것
- `\`\`\`json` 코드블록 안에 JSON 작성
